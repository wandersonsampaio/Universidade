package br.ufc.dao;

import java.util.List;

import br.ufc.model.Categoria;

public interface ICategoriaDAO {
	public List<Categoria> listarCategoria();
	public void inserirCategoria();
	public Categoria recuperar(Long id);
}
