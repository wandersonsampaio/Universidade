package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import br.ufc.model.Categoria;

@Repository
public class CategoriaDAOHibernate implements ICategoriaDAO{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public List<Categoria> listarCategoria() {
		// TODO Auto-generated method stub
		String hql = "select a from CATEGORIA as a";		
		return  manager.createQuery(hql,Categoria.class).getResultList();
	}
	@Override
	public void inserirCategoria() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Categoria recuperar(Long id) {
		// TODO Auto-generated method stub
		return manager.find(Categoria.class, id);
	}
	
}
