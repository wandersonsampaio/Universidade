package br.ufc.dao;

import java.util.List;

import br.ufc.model.Orkut;


public interface IOrkutDAO {
	
	public void inserir(Orkut orkut);
	public Orkut recuperar(String nome);
	public Orkut recuperar(Long ork_id);
	public List<Orkut> listar();

}
