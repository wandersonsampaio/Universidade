package br.ufc.dao;

import java.util.List;

import br.ufc.model.Forum;
import br.ufc.model.Mensagem;

public interface IForumDAO {

	public void inserir(Forum forum);

	public Forum recuperar(Long for_Id);

	public Forum recuperarMensagem(Long men_Id);

	public void atualizar(Forum forum);

	public Forum recuperar(String titulo);

	public List<Forum> listar();

	List<Mensagem> listarMensg(Long id);

	public  List<Forum> listarForum(Long id);

	public void apagar(Long for_Id);

}
