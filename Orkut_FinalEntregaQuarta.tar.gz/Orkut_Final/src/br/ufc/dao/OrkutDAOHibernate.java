package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import br.ufc.model.Orkut;



@Repository
public class OrkutDAOHibernate implements IOrkutDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public void inserir(Orkut orkut) {
		// TODO Auto-generated method stub
		manager.persist(orkut);
	}
	
	@Override
	public Orkut recuperar(String nome) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Orkut recuperar(Long ork_id) {
		return manager.find(Orkut.class, ork_id);

	}
	

	@Override
	public List<Orkut> listar() {
		String hql = "select o from ORKUT_QUIXADA as o";

		return manager.createQuery(hql, Orkut.class).getResultList();

	
	}
	
}
