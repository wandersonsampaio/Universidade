package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import br.ufc.model.Mensagem;

@Repository
public class MensagemDAOHibernate implements IMensagemDAO	 {
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public void inserir(Mensagem mensagem) {
		manager.persist(mensagem);
		
	}
	@Override
	public Mensagem recuperar(Long men_Id) {
		return manager.find(Mensagem.class, men_Id);
		
	}
	
	@Override
	public void atualizar(Mensagem mensagem) {
		manager.merge(mensagem);
		
	}
	
	@Override
	public Mensagem recuperar(String texto) {
		String hql = "select m from MENSAGEM as m "
				+ "where m.texto =:var_texto";
		Query query = manager.createQuery(hql, Mensagem.class);
		query.setParameter("var_texto", texto);
		List<Mensagem> mensagem = query.getResultList();

		if (mensagem != null && !mensagem.isEmpty()) {
			return mensagem.get(0);
		}

		return null;
	}
	@Override
	public List<Mensagem> listar() {
		String hql = "select m from MENSAGEM as m";

		return manager.createQuery(hql, Mensagem.class).getResultList();

	}
	@Override
	public void apagar(Long men_Id) {
		Mensagem m = this.recuperar(men_Id);
		manager.remove(m);
	}
}
