package br.ufc.dao;

import java.util.List;

import br.ufc.model.Mensagem;

public interface IMensagemDAO {

	void inserir(Mensagem mensagem);

	public Mensagem recuperar(Long men_Id);

	public void atualizar(Mensagem mensagem);

	public Mensagem recuperar(String texto);

	List<Mensagem> listar();

	public void apagar(Long men_Id);

}
