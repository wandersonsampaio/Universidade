package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import br.ufc.dao.ICategoriaDAO;
import br.ufc.model.Comunidade;
import br.ufc.model.Orkut;
import br.ufc.model.Forum;


@Repository
public class ComunidadeDAOHibernate implements IComunidadeDAO {

	@Autowired
	@Qualifier(value="categoriaDAOHibernate")
	private ICategoriaDAO categoriaDAO;
	
	@PersistenceContext
	private EntityManager manager;

	@Override
	public void inserir(Comunidade comunidade) {
		Orkut o = new Orkut();
		o.setOrk_id(1L);
		comunidade.setOrkut(o);
			manager.persist(comunidade);
	}
	@Override
	public void atualizar(Comunidade comunidade) {
		Orkut o = new Orkut();
		o.setOrk_id(1L);
		comunidade.setOrkut(o);
			manager.merge(comunidade);

	}
	@Override
	public Comunidade recuperarCategoria(Long cat_id) {
		return manager.find(Comunidade.class, cat_id);

	}
	@Override
	public Comunidade recuperar(Long com_id) {
		return manager.find(Comunidade.class, com_id);

	}
	
	@Override
	public Comunidade recuperar(String nome) {
		String hql = "select c from COMUNIDADE as c "
				+ "where c.nome =:var_nome";
		Query query = manager.createQuery(hql, Comunidade.class);
		query.setParameter("var_nome", nome);
		List<Comunidade> comunidade = query.getResultList();

		if (comunidade != null && !comunidade.isEmpty()) {
			return comunidade.get(0);
		}

		return null;
	}
	
	@Override
	public List<Comunidade> listar() {
		String hql = "select DISTINCT c from COMUNIDADE as c";

		return manager.createQuery(hql, Comunidade.class).getResultList();
	}
	
	@Override
	public void apagar(Long com_id) {
		Comunidade c = this.recuperar(com_id);
		manager.remove(c);

	}
	@Override
	public List<Forum> listarForum(Long id) {
		String hql = "select a from FORUM as a where com_id = :var_id";
		Query query = manager.createQuery(hql);
		query.setParameter("var_id", id);
		
		return query.getResultList();

	}
	
}
