package br.ufc.dao;

import java.util.List;

import br.ufc.model.Usuario;

public interface IUsuarioDAO {
	public void inserir(Usuario usuario);
	public void atualizar(Usuario usuario);
	public Usuario recuperar(String login);
	public Usuario recuperar(Long usu_id);
	public List<Usuario> listar();
	public List<Usuario> listarComunidade();
	public void apagar(Long id);

}
