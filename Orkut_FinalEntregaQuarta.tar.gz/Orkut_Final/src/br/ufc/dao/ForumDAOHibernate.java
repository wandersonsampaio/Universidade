package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import br.ufc.model.Forum;
import br.ufc.model.Mensagem;

@Repository
public class ForumDAOHibernate implements IForumDAO{

	@PersistenceContext
	private EntityManager manager;

	@Override
	public void inserir(Forum forum) {
		manager.persist(forum);		
	}
	
	@Override
	public Forum recuperar(Long for_Id) {
		return manager.find(Forum.class, for_Id);
		
	}

	@Override
	public Forum recuperarMensagem(Long men_Id) {
		return manager.find(Forum.class, men_Id);
		
	}
	@Override
	public void atualizar(Forum forum) {
		manager.merge(forum);
	}
	
	@Override
	public Forum recuperar(String titulo) {
		String hql = "select f from FORUM as f "
				+ "where f.titulo =:var_titulo";
		Query query = manager.createQuery(hql, Forum.class);
		query.setParameter("var_titulo", titulo);
		List<Forum> forum = query.getResultList();

		if (forum != null && !forum.isEmpty()) {
			return forum.get(0);
		}

		return null;
	}
	
	@Override
	public List<Forum> listar() {
		String hql = "select f from FORUM as f";

		return manager.createQuery(hql, Forum.class).getResultList();

	}
	
	@Override
	public List<Mensagem> listarMensg(Long id) {
		String hql = "select a from MENSAGEM as a where for_Id = :var_id";
		Query query = manager.createQuery(hql);
		query.setParameter("var_id", id);
		
		return query.getResultList();

	}
	@Override
	public List<Forum> listarForum(Long id) {
		String hql = "select a from FORUM as a where com_id = :var_id";
		Query query = manager.createQuery(hql);
		query.setParameter("var_id", id);
		
		return query.getResultList();

	}
	
	@Override
	public void apagar(Long for_Id) {
		Forum f = this.recuperar(for_Id);
		manager.remove(f);
		
	}

}
