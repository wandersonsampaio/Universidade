package br.ufc.model;

import java.util.Collection;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import br.ufc.model.Usuario;
import br.ufc.model.Forum;
import br.ufc.model.Categoria;
import br.ufc.model.Orkut;

@Entity(name = "COMUNIDADE")
public class Comunidade {

	@Id
	@Column(name = "COM_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long com_id;
	
	@Column(name = "NOME")
	private String nome;
	
	// MANY-TO-MANY:
		@ManyToMany
		@JoinTable(name = "USUARIO_COMUNIDADES", joinColumns = @JoinColumn(name = "COM_ID", referencedColumnName = "COM_ID"), inverseJoinColumns = @JoinColumn(name = "USU_ID", referencedColumnName = "USU_ID")

		)
		/*@ManyToMany
		@JoinTable(name="USUARIO_COMUNIDADE",
		joinColumns=@JoinColumn(name="USU_ID",referencedColumnName="USU_ID"),
		inverseJoinColumns=@JoinColumn(name="COM_ID", referencedColumnName="COM_ID"))
		
		private List<Comunidade> comunidades;*/
		
		private List<Usuario> usuarios;
		
		/* MANY-TO-ONE */
		@Column(name = "ORK_ID", insertable = false, updatable = false, nullable = false)
		private Long ork_Id;
		
		@OneToMany(mappedBy = "comunidade", targetEntity = Forum.class, fetch = FetchType.EAGER)
		private Collection<Forum> forum;
		
		/* many-to-one */
		@ManyToOne(optional = false)
		@JoinColumn(name = "ORK_ID", referencedColumnName = "ORK_ID")
		private Orkut orkut;
		
		@Column(name = "CAT_ID", insertable = false, updatable = false, nullable = false)
		private Long cat_Id;
		
		/* many-to-one */
		@ManyToOne(optional = false)
		@JoinColumn(name = "CAT_ID", referencedColumnName = "CAT_ID")
		private Categoria categoria;

		public Long getCom_id() {
			return com_id;
		}

		public void setCom_id(Long com_id) {
			this.com_id = com_id;
		}

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public List<Usuario> getUsuarios() {
			return usuarios;
		}

		public void setUsuarios(List<Usuario> usuarios) {
			this.usuarios = usuarios;
		}

		public Long getOrk_Id() {
			return ork_Id;
		}

		public void setOrk_Id(Long ork_Id) {
			this.ork_Id = ork_Id;
		}

		public Orkut getOrkut() {
			return orkut;
		}

		public void setOrkut(Orkut orkut) {
			this.orkut = orkut;
		}

		public Long getCat_Id() {
			return cat_Id;
		}

		public void setCat_Id(Long cat_Id) {
			this.cat_Id = cat_Id;
		}

		public Categoria getCategoria() {
			return categoria;
		}

		public void setCategoria(Categoria categoria) {
			this.categoria = categoria;
		}
		
		public Collection<Forum> getForum() {
			return forum;
		}

		public void setForum(Collection<Forum> forum) {
			this.forum = forum;
		}
		
		
}
