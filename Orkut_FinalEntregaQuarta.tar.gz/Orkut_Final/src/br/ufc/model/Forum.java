package br.ufc.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import br.ufc.model.Comunidade;
import br.ufc.model.Mensagem;

@Entity(name = "FORUM")
public class Forum {

	@Id
	@Column(name = "FOR_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long for_Id;
	
	@Column(name = "TITULO")
	private String titulo;

	@Column(name = "DESCRICAO")
	private String descricao;
	
	@Column(name = "COM_ID", insertable = false, updatable = false, nullable = false)
	private Long com_id;
	
	@ManyToOne(optional = false)
	@JoinColumn(name = "COM_ID", referencedColumnName = "COM_ID")
	private Comunidade comunidade;
	
	@OneToMany(mappedBy = "forum", targetEntity = Mensagem.class, fetch = FetchType.EAGER)
	private Collection<Mensagem> mensagem;
	
	@Column(name = "USU_ID")
	private Long usu_Id;

	public Long getUsu_Id() {
		return usu_Id;
	}

	public void setUsu_Id(Long usu_Id) {
		this.usu_Id = usu_Id;
	}

	@Column(name = "LOGIN")
	private String login;

	public Long getFor_Id() {
		return for_Id;
	}

	public void setFor_Id(Long for_Id) {
		this.for_Id = for_Id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Long getCom_id() {
		return com_id;
	}

	public void setCom_id(Long com_id) {
		this.com_id = com_id;
	}

	public Comunidade getComunidade() {
		return comunidade;
	}

	public void setComunidade(Comunidade comunidade) {
		this.comunidade = comunidade;
	}

	public Collection<Mensagem> getMensagem() {
		return mensagem;
	}

	public void setMensagem(Collection<Mensagem> mensagem) {
		this.mensagem = mensagem;
	}

	

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	

}
