package br.ufc.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import br.ufc.model.Comunidade;
import br.ufc.model.Usuario;

@Entity(name = "ORKUT_QUIXADA")
public class Orkut {
	
	@Id
	@Column(name = "ORK_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long ork_id;

	@Column(name = "NOME")
	private String nome;

	@Column(name = "DESCRICAO")
	private String descricao;
	
	@OneToMany(mappedBy = "orkut", targetEntity = Comunidade.class, fetch = FetchType.EAGER)
	private Collection<Comunidade> comunidades;
	
	@OneToMany(mappedBy = "orkut", targetEntity = Usuario.class, fetch = FetchType.EAGER)
	private Collection<Usuario> usuarios;

	public Long getOrk_id() {
		return ork_id;
	}

	public void setOrk_id(Long ork_id) {
		this.ork_id = ork_id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Collection<Comunidade> getComunidades() {
		return comunidades;
	}

	public void setComunidades(Collection<Comunidade> comunidades) {
		this.comunidades = comunidades;
	}

	public Collection<Usuario> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(Collection<Usuario> usuarios) {
		this.usuarios = usuarios;
	}
	
}
