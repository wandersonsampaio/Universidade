package br.ufc.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import br.ufc.model.Orkut;
import br.ufc.model.Comunidade;
import br.ufc.model.Amizade;

@Entity(name = "USUARIO")
public class Usuario {

	@Id
	@Column(name = "USU_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long usu_Id;
	
	@Column(name = "NOME")
	private String nome;

	@Column(name = "SOBRENOME")
	private String sobrenome;
	

	@Column(name = "IDADE")
	private int idade;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "LOGIN")
	private String login;

	@Column(name = "SENHA")
	private String senha;
	
	
	
	@Column(name = "ORK_ID", insertable = false, updatable = false, nullable = false)
	private Long ork_Id;
	
	/* many-to-one */
	@ManyToOne(optional = false)
	@JoinColumn(name = "ORK_ID", referencedColumnName = "ORK_ID")
	private Orkut orkut;
	
	/* many-to-many */
	@ManyToMany(mappedBy = "usuarios", fetch = FetchType.EAGER)
	private List<Comunidade> comunidades;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "usuarioFonte")
	private List<Amizade> amizades = new ArrayList<Amizade>();
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((usu_Id == null) ? 0 : usu_Id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (usu_Id == null) {
			if (other.usu_Id != null)
				return false;
		} else if (!usu_Id.equals(other.usu_Id))
			return false;
		return true;
	}
	
	
	
	public List<Amizade> getAmizades() {
		return amizades;
	}

	public void setAmizades(List<Amizade> amizades) {
		this.amizades = amizades;
	}
	
	
	
	public Long getUsu_Id() {
		return usu_Id;
	}

	public void setUsu_Id(Long usu_Id) {
		this.usu_Id = usu_Id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public Long getOrk_Id() {
		return ork_Id;
	}

	public void setOrk_Id(Long ork_Id) {
		this.ork_Id = ork_Id;
	}

	public Orkut getOrkut() {
		return orkut;
	}

	public void setOrkut(Orkut orkut) {
		this.orkut = orkut;
	}
	public List<Comunidade> getComunidades() {
		return comunidades;
	}
	public void setComunidades(List<Comunidade> comunidades) {
		this.comunidades = comunidades;
	}
	
	

}
