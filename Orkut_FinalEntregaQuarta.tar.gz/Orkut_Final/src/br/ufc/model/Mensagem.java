package br.ufc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import br.ufc.model.Forum;

@Entity(name = "MENSAGEM")
public class Mensagem {
	
	@Id
	@Column(name = "MEN_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long men_Id;
	
	
	@Column(name = "TEXTO")
	private String texto;

	@Column(name = "FOR_ID", insertable = false, updatable = false, nullable = false)
	private Long for_Id;
	
	@ManyToOne(optional = false)
	@JoinColumn(name = "FOR_ID", referencedColumnName = "FOR_ID")
	private Forum forum;

	@Column(name = "USU_ID")
	private Long usu_Id;

	@Column(name = "LOGIN")
	private String login;

	public Long getMenId() {
		return men_Id;
	}

	public Long getUsuId() {
		return usu_Id;
	}

	public Long getMen_Id() {
		return men_Id;
	}

	public void setMen_Id(Long men_Id) {
		this.men_Id = men_Id;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public Long getFor_Id() {
		return for_Id;
	}

	public void setFor_Id(Long for_Id) {
		this.for_Id = for_Id;
	}

	public Forum getForum() {
		return forum;
	}

	public void setForum(Forum forum) {
		this.forum = forum;
	}

	public Long getUsu_Id() {
		return usu_Id;
	}

	public void setUsu_Id(Long usu_Id) {
		this.usu_Id = usu_Id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}
	
	
}
