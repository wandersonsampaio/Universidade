package br.ufc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import br.ufc.dao.IOrkutDAO;
import br.ufc.model.Orkut;

@Controller
@Transactional
public class OrkutController {

	
	@Autowired
	@Qualifier(value = "orkutDAOHibernate")
	private IOrkutDAO orkutDAO;

	@RequestMapping("/inserirOrkutFormulario")

	public String inserirOrkutFormulario() {
		return "orkutquixada/inserir_orkut_formulario";
	}

	@RequestMapping("/inserirOrkut")
	public String inserirOrkut(Orkut orkut) {
		orkutDAO.inserir(orkut);
		return "orkut/inserir_ok";
	}



}
