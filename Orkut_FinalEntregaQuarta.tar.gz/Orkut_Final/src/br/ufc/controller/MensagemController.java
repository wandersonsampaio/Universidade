package br.ufc.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import br.ufc.dao.IForumDAO;
import br.ufc.dao.IMensagemDAO;
import br.ufc.model.Forum;
import br.ufc.model.Mensagem;
import br.ufc.model.Usuario;

@Controller
@Transactional
public class MensagemController {
		
	@Autowired
	@Qualifier(value = "forumDAOHibernate")
	private IForumDAO forumDAO;

	@Autowired
	@Qualifier(value = "mensagemDAOHibernate")
	private IMensagemDAO mensagemDAO;

	@Autowired
	private ServletContext context;
	
	@RequestMapping("/inserirMensagemFormulario")
	// links
	public String inserirMensagemFormulario(Model model, HttpSession session,
			Long id) {

		Forum forum = forumDAO.recuperar(id);
		session.setAttribute("forum", forum);
		return "mensagem/inserir_mensagem_formulario";
	}
	
	@RequestMapping("/inserirMensagem")
	public String inserirMensagem(HttpSession session, Mensagem mensagem) {

		Forum f = (Forum) session.getAttribute("forum");
		mensagem.setForum(f);
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		mensagem.setUsu_Id(u.getUsu_Id());
		mensagem.setLogin(u.getLogin());

		mensagemDAO.inserir(mensagem);

		return "redirect:listarMensagem";

	}
	@RequestMapping("/listarMensagem")
	public String listarMensagem(Model model, Long id) {
		List<Mensagem> mensagem = forumDAO.listarMensg(id);
		model.addAttribute("mensagem", mensagem);
		return "mensagem/listar_mensagem";
	}

	@RequestMapping("/apagarMensagem")
	public String apagarMensagem(Long men_Id) {
		mensagemDAO.apagar(men_Id);
		return "redirect:listarMensagem";

	}
}
