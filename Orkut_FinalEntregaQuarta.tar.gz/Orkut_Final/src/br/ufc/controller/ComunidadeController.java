package br.ufc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import br.ufc.dao.IComunidadeDAO;
import br.ufc.dao.IUsuarioDAO;
import br.ufc.model.Categoria;
import br.ufc.model.Comunidade;
import br.ufc.model.Usuario;
import br.ufc.util.AulaFileUtil;
import br.ufc.dao.ICategoriaDAO;

@Controller
@Transactional
public class ComunidadeController {
	
	@Autowired
	@Qualifier(value = "comunidadeDAOHibernate")
	private IComunidadeDAO comunidadeDAO;
	
	@Autowired
	@Qualifier(value = "categoriaDAOHibernate")
	private ICategoriaDAO categoriaDAO;
	
	@Autowired
	@Qualifier(value = "usuarioDAOHibernate")
	private IUsuarioDAO usuarioDAO;
	
	@Autowired
	private ServletContext context;
	
	@RequestMapping("/inserirComunidadeFormulario")
	// links
	public String inserirComunidadeFormulario(Model model) {
		List<Categoria> categoria = categoriaDAO.listar();
		model.addAttribute("categoria", categoria);

		return "comunidades/inserir_comunidade_formulario";
	}
	@RequestMapping("/inserirComunidade")
	public String inserirComunidade(HttpSession session, Comunidade comunidade,
			@RequestParam(value = "image", required = false) MultipartFile image) {

		// USUARIO_COMUNIDADES
		List<Usuario> users = new ArrayList<Usuario>();
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		users.add(u);

		if (image != null && !image.isEmpty()) {
			String path = context.getRealPath("/");
			path += "resources/images/" + comunidade.getNome() + ".png";
			AulaFileUtil.saveFile(path, image);

		}
		Categoria c = categoriaDAO.recuperar(comunidade.getCat_Id());
		comunidade.setCategoria(c);
		
		comunidade.setUsuarios(users);
		comunidadeDAO.inserir(comunidade);

		return "redirect:listarMinhasComunidades";

	}
	@RequestMapping("/adicionarComunidadeFormulario")
	public String adicionarComunidadeFormulario(Model model) {
		List<Comunidade> comunidade = comunidadeDAO.listar();
		model.addAttribute("comunidade", comunidade);
		return "comunidades/adicionar_comunidade_formulario";
	}
	@RequestMapping("/adicionarComunidade")
	public String adicionarComunidade(HttpSession session, Comunidade comunidade) {
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		Comunidade cT = comunidadeDAO.recuperar(comunidade.getCom_id());
		cT.getUsuarios().add(u);

		comunidadeDAO.atualizar(cT);

		return "redirect:listarMinhasComunidades";

	}
	@RequestMapping("/listarComunidade")
	public String listarComunidade(Model model) {
		List<Comunidade> comunidades = comunidadeDAO.listar();
		model.addAttribute("comunidades", comunidades);
		return "comunidades/listar_comunidade";
	}
	
	@RequestMapping("/listarMinhasComunidades")
	public String listarMinhasComunidades(Model model, HttpSession session) {
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		List<Comunidade> comu = u.getComunidades();
		model.addAttribute("comu", comu);
		return "comunidades/listar_minhas_comunidades";
	}
	@RequestMapping("/alterarComunidadeFormulario")
	public String alterarComunidadeFormulario(Long com_id, Model model) {
		Comunidade comunidade = comunidadeDAO.recuperar(com_id);
		model.addAttribute("comunidade", comunidade);
		return "comunidades/alterar_comunidade_formulario";

	}
	
	@RequestMapping("/alterarComunidade")
	public String alterarComunidade(Comunidade c, Model model,
			@RequestParam(value = "image", required = false) MultipartFile image) {

		if (image != null && !image.isEmpty()) {
			String path = context.getRealPath("/");
			path += "resources/images/" + c.getNome() + ".png";
			AulaFileUtil.saveFile(path, image);

		}
		Categoria ca = categoriaDAO.recuperar(c.getCat_Id());
		c.setCategoria(ca);

		comunidadeDAO.atualizar(c);
		return "redirect:listarMinhasComunidades";

	}
	
}
