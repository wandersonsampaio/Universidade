package br.ufc.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import br.ufc.dao.IForumDAO;
import br.ufc.model.Comunidade;
import br.ufc.model.Usuario;
import br.ufc.model.Forum;
import br.ufc.dao.IComunidadeDAO;

@Controller
@Transactional
public class ForumController {
	
	@Autowired
	@Qualifier(value = "forumDAOHibernate")
	private IForumDAO forumDAO;
	
	@Autowired
	@Qualifier(value = "comunidadeDAOHibernate")
	private IComunidadeDAO comunidadeDAO;
	
	
	@Autowired
	private ServletContext context;

	@RequestMapping("/inserirForumFormulario")
	// links
	public String inserirForumFormulario(Model model, HttpSession session) {
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		List<Comunidade> comunidade = u.getComunidades();
		model.addAttribute("comunidade", comunidade);
		return "forum/inserir_forum_formulario";
	}
	@RequestMapping("/inserirForum")
	public String inserirForum(Forum forum, HttpSession session) {

		Comunidade c = comunidadeDAO.recuperar(forum.getCom_id());
		forum.setComunidade(c);
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		forum.setUsu_Id(u.getUsu_Id());
		forum.setLogin(u.getLogin());
		forumDAO.inserir(forum);
		return "redirect:listarForum";

	}
	@RequestMapping("/apagarForum")
	public String apagarForum(Long for_Id) {
		forumDAO.apagar(for_Id);
		return "redirect:listarForum";

	}
	@RequestMapping("/listarForum")
	public String listarForum(Model model, Long id) {
		List<Forum> forum = comunidadeDAO.listarForum(id);
		model.addAttribute("forum", forum);
		return "forum/listar_forum";
	}
}
