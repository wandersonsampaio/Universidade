package br.ufc.excecoes;

public class LoginException extends Exception {
	public LoginException() {

	}

	public LoginException(String msg) {
		super(msg);
	}

}