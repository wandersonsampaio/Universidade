package br.ufc.dao;

import java.util.List;

import br.ufc.model.Comunidade;


public interface IComunidadeDAO {

	
	void criarComunidade(Comunidade comunidade);
	public List<Comunidade> listarComunidades();
	public Comunidade recuperar(Long id);	
	public void cadastroNaComunidade(Comunidade c);
	
	
}
