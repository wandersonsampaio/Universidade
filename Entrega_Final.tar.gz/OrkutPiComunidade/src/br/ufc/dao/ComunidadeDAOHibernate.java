package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.springframework.stereotype.Repository;

import br.ufc.model.Comunidade;

@Repository
public class ComunidadeDAOHibernate implements IComunidadeDAO {
	@PersistenceContext
	private EntityManager manager; 
	

	@Override
	public void criarComunidade(Comunidade comunidade){		
		manager.merge(comunidade);
	}	
	@Override
	public List<Comunidade> listarComunidades() {
		String hql = "select u from COMUNIDADE as u";
		return manager.createQuery(hql,Comunidade.class).getResultList();				 
	}
	
	@Override
	public Comunidade recuperar(Long id) {
		// TODO Auto-generated method stub
		return manager.find(Comunidade.class, id);
	}
	@Override
	public void cadastroNaComunidade(Comunidade c) {		
		manager.merge(c);
	}


}
