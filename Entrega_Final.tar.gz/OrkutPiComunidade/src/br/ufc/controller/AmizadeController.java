package br.ufc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import br.ufc.dao.IAmizadeDAO;
import br.ufc.dao.IUsuarioDAO;
import br.ufc.model.Amizade;
import br.ufc.model.Usuario;

@Controller
@Transactional
public class AmizadeController {

	@Autowired
	@Qualifier(value = "amizadeDAOHibernate")
	private IAmizadeDAO amizadeDAO;

	@Autowired
	@Qualifier(value = "usuarioDAOHibernate")
	private IUsuarioDAO usuarioDAO;

	@Autowired
	private ServletContext context;
	
	@RequestMapping("/listarAmigos")
	public String listarAmigos(HttpSession session, Model model) {
		Usuario u = (Usuario) session.getAttribute("usuario_logado");

		List<Amizade> amigos = this.amizadeDAO.listarAmizadesDeId(u.getId());
		List<Usuario> usuarios = new ArrayList<Usuario>();

		for (Amizade a : amigos) {
			Long amigoId = a.getUsuarioAlvo().getId();
			Usuario usuario = usuarioDAO.recuperar(amigoId);
			usuarios.add(usuario);
		}

		model.addAttribute("amizades", usuarios);
		return "usuarios/listar_amigos";
	}
}
